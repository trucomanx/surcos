%
pkg load signal
addpath(genpath('mfiles'))
% IMG1   = double(imread ("../images/images0/test2.bmp"));
% IMG1   = double(imread ("../images/images1/0069_Nir_8b_GeoRef.tiff")); IMG1=IMG1(1600:1750,850:1000);
% IMG1   = double(imread ("../images/images2/0069_Nir.tiff"));  
 IMG1   = double(imread ("../images/images1/0069_Nir_8b_GeoRef.tiff"));
 IMG1=IMG1(1550:1750,800:1000);

figure(1)
imagesc(IMG1)
daspect([1 1 1])
colormap(jet)
MINIMG1=mean(mean(IMG1));


figure(2)

Y = fft2( IMG1-MINIMG1);
L0=round(size(Y,1)/2);
C0=round(size(Y,2)/2);
AFFT=abs(fftshift(Y));
L=20;
surfc(AFFT(L0+[-L:L],C0+[-L:L]))
colormap(jet)
%daspect([1 1 0.01])
shading interp;
view([0 90])


figure(3)
%Y=func_clean_lines_in_images(Y,5);
B = abs(ifft2(Y)-min(min(ifft2(Y))));
imagesc(B)
daspect([1 1 1])
colormap(jet)


figure(4)
surfc(B)
colormap(jet)
shading interp;
