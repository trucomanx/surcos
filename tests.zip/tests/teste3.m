%
Nx=24; % columns
Ny=32; % lines
X=[0:(Nx-1)];
Y=[0:(Ny-1)];


fx=2/Nx;
fy=6/Ny;


[XX, YY] = meshgrid (X,Y);
DATA=sin(2*pi*(fx*XX+fy*YY));


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
Z = fft2(DATA-mean(mean(DATA)));
AZ=abs(fftshift(Z));
BZ=double(AZ/max(max(AZ))>0.5);

IDS=find(BZ==1);
[L1 C1 ]=ind2sub(size(BZ),IDS(1));
P1=[C1 L1]; %% x,y
[L2 C2 ]=ind2sub(size(BZ),IDS(2));
P2=[C2 L2]; %% x,y

Pr=(P2-P1)/2


function [Pl Pp Pc ]=func_get_data2(Nx,Ny,P1,P2)
    Pc=(P1+P2)/2;
    Pr=P2-Pc;

    Pp=[Pr(1)/Nx Pr(2)/Ny]; Pp=Pp/norm(Pp)^2;
    Pl=Pp*[0 1;-1 0];

endfunction

[Pl Pp Pc ]=func_get_data2(Nx,Ny,P1,P2)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
figure(1)
s=pcolor(BZ);
colormap(jet)
xlabel('x')
ylabel('y')
set(s,'EdgeColor','black')
set(s,'LineWidth',3)
daspect([1 1 1])
grid minor on
hold on
scatter((Nx+1)/2+1,(Ny+1)/2+1)
text(P1(1)+1,P1(2),'P1','color','red');
text(P2(1)+1,P2(2),'P2','color','red');
hold off
hold on
quiver(Pc(1),Pc(2),Pr(1),Pr(2),'LineWidth',6);
hold off
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
figure(2);
pcolor(DATA)
xlabel('x')
ylabel('y')
colormap(jet)
daspect([1 1 1])
hold on
for II=-2:2
    P0=Pc+II*Pp;
    quiver(P0(1),P0(2),Pl(1),Pl(2),'k','LineWidth',6);
endfor
hold off


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
figure(3);
surf(DATA);
xlabel('x')
ylabel('y')
colormap(jet)
daspect([1 1 1])

