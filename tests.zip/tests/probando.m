%

addpath(genpath('mfiles'));

IMG_RED   = double(imread ("../images/images1/0069_Red_8b_GeoRef.tiff"));
IMG_GREEN = double(imread ("../images/images1/0069_Green_8b_GeoRef.tiff"));
IMG_BLUE  = double(imread ("../images/images1/0069_Blue_8b_GeoRef.tiff"));
IMG_NIR   = double(imread ("../images/images1/0069_Nir_8b_GeoRef.tiff"));
IMG_REDGE = double(imread ("../images/images1/0069_REdge_8b_GeoRef.tiff"));


imagesc_bands(IMG_RED,IMG_GREEN,IMG_BLUE,IMG_NIR,IMG_REDGE);

IMG_RGB=func_rgb_norm(IMG_RED,IMG_GREEN,IMG_BLUE);

figure(6)
imshow(IMG_RGB);
daspect([1 1 1])

%imwrite (J, "my_output_image.img");
