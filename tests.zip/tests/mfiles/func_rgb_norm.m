function IMG_RGB=func_rgb_norm(IMG_RED,IMG_GREEN,IMG_BLUE)
    IMG_RGB=zeros([size(IMG_RED) 3]);

    IMG_RGB(:,:,1)=IMG_RED;
    IMG_RGB(:,:,2)=IMG_GREEN;
    IMG_RGB(:,:,3)=IMG_BLUE;

    MAX=1.0*max(max(max(IMG_RGB)));
    
    IMG_RGB=IMG_RGB/MAX;
endfunction
