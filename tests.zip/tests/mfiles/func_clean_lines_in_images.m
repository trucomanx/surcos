function IMGOUT=func_clean_lines_in_images(IMG,PCT)
    NLIN=size(IMG,1);
    NCOL=size(IMG,2);

    NL=round((1-PCT/100)*NLIN);
    NC=round((1-PCT/100)*NCOL);

    IMGOUT=zeros(size(IMG));

    IMGOUT(1:NL,1:NC)=IMG(1:NL,1:NC);
    
endfunction
