function imagesc_bands(IMG_RED,IMG_GREEN,IMG_BLUE,IMG_NIR,IMG_REDGE)

    figure(1);
    imagesc(IMG_RED);
    title('RED');
    daspect([1 1 1]);
    colormap(jet);

    figure(2);
    imagesc(IMG_GREEN);
    title('GREEN');
    daspect([1 1 1]);
    colormap(jet);

    figure(3);
    imagesc(IMG_BLUE);
    title('BLUE');
    daspect([1 1 1]);
    colormap(jet);

    figure(4);
    imagesc(IMG_NIR);
    title('NIR');
    daspect([1 1 1]);
    colormap(jet);

    figure(5);
    imagesc(IMG_REDGE);
    title('REDGE');
    daspect([1 1 1]);
    colormap(jet);
endfunction
